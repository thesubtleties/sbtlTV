#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>

#include "osdep/compiler.h"

#include "ta/ta_talloc.h"
