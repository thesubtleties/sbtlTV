#include "main-fn.h"

int main(int argc, char *argv[])
{
    return mpv_main(argc, argv);
}
